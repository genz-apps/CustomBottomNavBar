package com.genzapps.custombottomnavbar;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.Map;

public class customNavBar extends FrameLayout {
    private BottomNavigationView bottomNav;
    private ImageView movingCircle;
    private ImageView curveBackground;
    private Map<Integer, Float> positions = new HashMap<>();

    public customNavBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        inflate(context, R.layout.view_circle_bottom_nav, this);

        bottomNav = findViewById(R.id.bottom_nav);
        movingCircle = findViewById(R.id.movingCircle);
        curveBackground = findViewById(R.id.curveBackground);

        // Load custom attributes from XML
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.customNavBar);
        int circleDrawableRes = a.getResourceId(R.styleable.customNavBar_circleDrawable, R.drawable.nav_curve_background);
        int curveDrawableRes = a.getResourceId(R.styleable.customNavBar_curveDrawable, R.drawable.curve_background);
        a.recycle();

        // Set drawables
        movingCircle.setBackgroundResource(circleDrawableRes);
        curveBackground.setImageResource(curveDrawableRes);

        bottomNav.post(this::calculatePositions);

        bottomNav.setOnNavigationItemSelectedListener(item -> {
            moveCircle(item.getItemId());
            return true;
        });
    }

    private void calculatePositions() {
        int[] menuItems = {R.id.nav_home, R.id.nav_category, R.id.nav_profile};
        ViewGroup menuView = (ViewGroup) bottomNav.getChildAt(0);

        for (int i = 0; i < menuItems.length; i++) {
            View itemView = menuView.getChildAt(i);
            float centerX = itemView.getX() + (itemView.getWidth() / 2f) - (movingCircle.getWidth() / 2f);
            positions.put(menuItems[i], centerX);
        }

        if (positions.get(R.id.nav_home) != null) {
            movingCircle.setTranslationX(positions.get(R.id.nav_home));
        }
    }

    private void moveCircle(int itemId) {
        Float targetX = positions.get(itemId);
        if (targetX == null) return;

        ObjectAnimator animator = ObjectAnimator.ofFloat(movingCircle, "translationX", targetX);
        animator.setDuration(300);
        animator.start();
    }

    public BottomNavigationView getBottomNav() {
        return bottomNav;
    }
}
